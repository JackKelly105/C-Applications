﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheCollegeApplication
{
    public class Student : Person
    {


        public string email { get; set; }
        public string course { get; set; }
        public string yearofregistration { get; set; }
        public HashSet<string> Mcode { get; set; }
        public Student(string firstName, string surname, string Knumber, string ContactNumber, string email, string course, string yearofregistration, HashSet<string> Mcode) : base(firstName, surname, Knumber, ContactNumber)
        {
            this.course = course;
            this.yearofregistration = yearofregistration;
            this.email = email;
            this.Mcode = Mcode;
        }

        public override void Print()
        {
            Console.WriteLine("First Name: " + firstName + "\n" + "Sur Name: " + surname + "\n" + "Knumber: " + Knumber + "\n" + "Contact Number: " + ContactNumber + "\n" + "Email: " + email + "\n" + "Course: " + course + "\n" + "Year of Registration: " + yearofregistration + "\n" + "Module Codes");

            foreach (string i in Mcode)
            {
                Console.Write(i + " " + "\n");

            }
            Console.WriteLine();
        }
        public override void Update()
        {
            firstName = Console.ReadLine();
            surname = Console.ReadLine();
            Knumber = Console.ReadLine();
            ContactNumber = Console.ReadLine();
            email = Console.ReadLine();
            course = Console.ReadLine();
            yearofregistration = Console.ReadLine();
            

        }
        public void PrintEmailPerModule()
        {
            Console.WriteLine("\n" + "Email: " + email + "\n" + "Module Codes");

            foreach (string i in Mcode)
            {
                Console.Write(i + " " + "\n");

            }
            Console.WriteLine();
        }
        public void PrintEmail()
        {
            Console.WriteLine("\n" + "Email: " + email);
        }
        public void PrintModuleCodes()
        {
            foreach (string i in Mcode)
            {
                Console.Write(i + " " + "\n");

            }
          
        }
        public void PrintStudents()
        {
            Console.WriteLine(firstName + " " + surname + " " + Knumber);
        }
    }
    }
