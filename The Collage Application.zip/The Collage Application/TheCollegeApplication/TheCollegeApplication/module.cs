﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheCollegeApplication
{
    public class module
    {
        public string moduleCode { get; set; }
        public string moduleName { get; set; }
        public string description { get; set; }
        public int MaxNumberOfPlaces { get; set; }
        public int MinNumberOfPlaces { get; set; }

        public module( string moduleCode, string moduleName, string description, int MaxNumberOfPlaces, int MinNumberOfPlaces)
        {
            this.moduleCode = moduleCode;
            this.moduleName = moduleName;
            this.description = description;
            this.MaxNumberOfPlaces = MaxNumberOfPlaces;
            this.MinNumberOfPlaces = MinNumberOfPlaces;

        }

        public void PrintModules()
        {
            Console.WriteLine("Module Code: " + moduleCode + "\n" + "Module Name: " + moduleName + "\n" + "Description: " + description + "\n" + "Max Number of Places: " + MaxNumberOfPlaces + "\n" + "Min Number of Places: " + MinNumberOfPlaces + "\n");
        }
    }
}
