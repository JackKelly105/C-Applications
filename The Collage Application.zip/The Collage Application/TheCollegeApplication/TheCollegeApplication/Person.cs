﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheCollegeApplication
{
    public abstract class Person
    {
        public string firstName { get; set; }
        public string surname { get; set; }
        public string Knumber { get; set; }
        public string ContactNumber { get; set; }

        public Person(string firstName, string surname, string Knumber, string ContactNumber)
        {
            this.firstName = firstName;
            this.surname = surname;
            this.Knumber = Knumber;
            this.ContactNumber = ContactNumber;

        }

        public virtual void Update()
        {
            firstName = Console.ReadLine();
            surname = Console.ReadLine();
            Knumber = Console.ReadLine();
            ContactNumber = Console.ReadLine();
        }

        public abstract void Print();
    }
}
