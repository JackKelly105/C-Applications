﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TheCollegeApplication
{
    class Program
    {
        public static void AddStudent(List<Student> Students)
        {
            HashSet<string> Mcode1 = new HashSet<string>();
            Mcode1.Add("345");
            Mcode1.Add("646");
            Mcode1.Add("456");
            Mcode1.Add("983");
            HashSet<string> Mcode2 = new HashSet<string>();
            Mcode2.Add("364");
            Mcode2.Add("756");
            Mcode2.Add("089");
            Mcode2.Add("353");


            Student s1 = new Student("Jack", "Kelly", "K00236610", "0851051010", "K00236610@student.lit.ie", "Software Development", "2018", Mcode1);
            Student s2 = new Student("Bob", "Marley", "K00236613", "0853045566", "K00236613@student.lit.ie", "Software Development", "2018", Mcode1);
            Student s3 = new Student("Darth", "Vader", "K00236568", "0868934014", "K00236568@student.lit.ie", "Software Development", "2018", Mcode1);
            Student s4 = new Student("Iron", "Man", "K00237745", "0879834607", "K00237745@student.lit.ie", "Software Development", "2017", Mcode1);
            Student s5 = new Student("Bill", "Gates", "K00456679", "0857809241", "K00456679@student.lit.ie", "ISD", "2016", Mcode2);
            Student s6 = new Student("William", "Ferrell", "K00124587", "087892308", "K00124587@student.lit.ie", "ISD", "2016", Mcode2);
            Student s7 = new Student("Bruce", "Willis", "K00340965", "086751092", "K00340965@student.lit.ie", "ISD", "2017", Mcode2);
            Student s8 = new Student("Post", "Malone", "K00314093", "087704325", "K00314093@student.lit.ie", "ISD", "2017", Mcode2);
            Students.Add(s1);
            Students.Add(s2);
            Students.Add(s3);
            Students.Add(s4);
            Students.Add(s5);
            Students.Add(s6);
            Students.Add(s7);
            Students.Add(s8);

        }
      
        public static void AddModule(List<module> Modules)

        {
            module m1 = new module("345", "OOTAP", "Understand the Structure of a C# program", 40, 20);
            module m2 = new module("646", "Maths", "Study of Mathematical Structures", 40, 20);
            module m3 = new module("456", "DataBase", "Study of software that handles the storage, retrieval, and updating of data in a computer system", 40, 20);
            module m4 = new module("983", "Networking", "Study of Digital Telecommunications Networks", 40, 20);
            module m5 = new module("364", "Web Techniques", "Study of web Techniques", 30, 10);
            module m6 = new module("756", "Software Development", "Study of software development", 30, 10);
            module m7 = new module("089", "Web Project", "Study of web projects", 30, 20);
            module m8 = new module("353", "Databases for Project", "Study of database projects", 40, 10);

            Modules.Add(m1);
            Modules.Add(m2);
            Modules.Add(m3);
            Modules.Add(m4);
            Modules.Add(m5);
            Modules.Add(m6);
            Modules.Add(m7);
            Modules.Add(m8);

        }

        public static void displayStudents(List<Student> Students)
        {
            
            foreach (Student a in Students)
            {
                a.Print();

            }
           
        }
        public static void displayModules(List<module> Modules)
        {
            
            foreach (module a in Modules)
            {
                a.PrintModules();

            }
      
        }
        
        public static void UpdateStudentModuleDetailsbyKnumber(List<Student> Students)
        {
            Console.WriteLine("Search By Knumber - Enter in Knumber");
            String SKnumber = Console.ReadLine();
           
            foreach (Student a in Students)
            {
                if (a.Knumber.Equals(SKnumber))
                {
                    a.Print();
                    a.Update();
                    
                }
            }
           
        }
        public static void PrintEmailPerModule(List<Student> Students)
        {

            foreach (Student a in Students)
            {
                a.PrintEmailPerModule();

            }

        }
        public static void Searchbycourseandyear(List<Student> Students)
        {
            Console.WriteLine("Search By course - Enter in course");
            String course = Console.ReadLine();
            Console.WriteLine("Search By year - Enter in year");
            String year = Console.ReadLine();

            foreach (Student a in Students)
            {

                if (a.course.Contains(course) && a.yearofregistration.Contains(year))
                {
                    Console.WriteLine("\n" + course);
                    a.PrintModuleCodes();
                   
                }
            }
            

        }
        public static void Searchbycourseandyear1(List<Student> Students)
        {
            Console.WriteLine("Search By course - Enter in course");
            String course = Console.ReadLine();
            Console.WriteLine("Search By year - Enter in year");
            String year = Console.ReadLine();

            foreach (Student a in Students)
            {

                if (a.course.Contains(course) && a.yearofregistration.Contains(year))
                {
                    Console.WriteLine("\n" + course);
                    a.PrintModuleCodes();
                    a.PrintStudents();
                   
                }
            }


        }
        public static void SearchbyMcode1(List<Student> Students)
        {
            Console.WriteLine("Search By ModuleCode - Enter in ModuleCode");
            String mcode = Console.ReadLine();
            Console.WriteLine("Search By ModuleCode - Enter in ModuleCode");
            String mcode1 = Console.ReadLine();
           
            foreach (Student a in Students)
            {

                if (a.Mcode.Contains(mcode) && a.Mcode.Contains(mcode1))
                {
                    a.PrintEmail();
                    Console.WriteLine("Module Codes {0} {1}", mcode, mcode1);
                }
            }
            
        }
        public static void SearchbyMcode2(List<Student> Students)
        {
            Console.WriteLine("Search By ModuleCode - Enter in ModuleCode");
            String mcode = Console.ReadLine();
            Console.WriteLine("Search By ModuleCode - Enter in ModuleCode");
            String mcode1 = Console.ReadLine();
            Console.WriteLine("Search By ModuleCode - Enter in ModuleCode");
            String mcode3 = Console.ReadLine();
            Console.WriteLine("Search By ModuleCode - Enter in ModuleCode");
            String mcode4 = Console.ReadLine();
            foreach (Student a in Students)
            {
               
                if (a.Mcode.Contains(mcode) && a.Mcode.Contains(mcode1) && a.Mcode.Contains(mcode3) && a.Mcode.Contains(mcode4))
                    {
                        a.PrintEmailPerModule();

                    }
            }
        }
            static void Main()
        {

          
            List<Student> Students = new List<Student>();
            List<module> Modules = new List<module>();
            HashSet<Student> Mcode = new HashSet<Student>();

            Console.WriteLine("\n" + "** The College Application **");

            int option = 0;
            do
            {
                Console.WriteLine("---------------------------------------");
                Console.WriteLine("1.   Add Students");
                Console.WriteLine("2.   Add Modules");
                Console.WriteLine("3.   System Data");
                Console.WriteLine("4.   Update Student Module Details");
                Console.WriteLine("5.   Management Information");
                Console.WriteLine("6.   Manage Email Lists");
                Console.WriteLine("---------------------------------------");
                option = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine(option);
                switch (option)
                {
                    case 1:
                        {
                            AddStudent(Students);
                            break;
                        }
                    case 2:
                        {
                            AddModule(Modules);
                            break;
                        }
                    case 3:
                        {
                            int data = 0;
                            do
                            {
                                Console.WriteLine("---------------------------------------");
                                Console.WriteLine("1   Display Students");
                                Console.WriteLine("2   Display Modules");
                                Console.WriteLine("3   Exit Sub Menu");
                                Console.WriteLine("---------------------------------------");
                                data = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine(data);
                                switch (data)
                                {
                                    case 1:
                                        {
                                            displayStudents(Students);
                                            break;
                                        }
                                    case 2:
                                        {
                                            displayModules(Modules);
                                            break;
                                        }
                                    case 3:
                                        {
                                            
                                            break;
                                        }
                                    
                                }
                            } while (data != 3);
                            
                            break;
                        }
                    case 4:
                        {
                            UpdateStudentModuleDetailsbyKnumber(Students);
                            break;
                        }
                    case 5:
                        {
                            int data = 0;
                            do
                            {
                                Console.WriteLine("----------------------------------------------------------------------");
                                Console.WriteLine("1.   Display modules that fail min places");
                                Console.WriteLine("2.   Display most popular module combination");
                                Console.WriteLine("3.   Display most popular module combination along with students");
                                Console.WriteLine("4.   Exit Sub Menu");
                                Console.WriteLine("----------------------------------------------------------------------");
                                data = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine(data);
                                switch (data)
                                {
                                    case 1:
                                        {
                                            
                                            break;
                                        }
                                    case 2:
                                        {
                                            Searchbycourseandyear(Students);
                                            break;
                                        }
                                    case 3:
                                        {
                                            Searchbycourseandyear1(Students);
                                            break;
                                        }
                                    
                                    case 4:
                                        {

                                            break;
                                        }

                                }
                            } while (data != 4);
                            break;
                        }
                    case 6:
                        {
                            int data = 0;
                            do
                            {
                                Console.WriteLine("----------------------------------------------------------------------");
                                Console.WriteLine("1.   Display List of Email Addresses Per Course");
                                Console.WriteLine("2.   Display List of Email Addresses Per Course And Per Year");
                                Console.WriteLine("3.   Display List of Email Addresses Per Module");
                                Console.WriteLine("4.   Display List of Email Addresses Per Module combination");
                                Console.WriteLine("5.   Display List of Email Addresses for either Module combination");
                                Console.WriteLine("6.   Exit Sub Menu");
                                Console.WriteLine("----------------------------------------------------------------------");
                                data = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine(data);
                                switch (data)
                                {
                                    case 1:
                                        {
                                            var i = Students.OrderBy(n => n.course).GroupBy(n => new { n.course, n.email }).Select(g => new { Student = g.Key }).ToList();
                                            foreach (var a in i)
                                            {
                                                Console.WriteLine(a);
                                            }
                                            break;
                                        }
                                    case 2:
                                        {
                                            var i = Students.OrderBy(n => n.course).GroupBy(n => new { n.course, n.email ,n.yearofregistration }).Select(g => new { Student = g.Key }).ToList();
                                            foreach (var a in i)
                                            {
                                                Console.WriteLine(a);
                                            }
                                            break;
                                        }
                                    case 3:
                                        {
                                            PrintEmailPerModule(Students);
                                            break;
                                        }
                                    case 4:
                                        {
                                            SearchbyMcode1(Students);
                                            break;
                                        }
                                    case 5:
                                        {
                                            SearchbyMcode2(Students);
                                            break;
                                        }
                                    case 6:
                                        {
                                           
                                            break;
                                        }

                                }
                            } while (data != 6);

                            break;
                        }

                    default:
                        {
                            Console.WriteLine("option was invalid ");
                            break;
                        }
                }

            } while (option != 7);
        }

        
    }
    
}
    

